# 📊 Data Pipeline Documentation

## Overview

This smartwatch data analysis application implements a complete **ETL (Extract, Transform, Load)** pipeline with three distinct phases:

1. **Ingestion** - Data loading and validation
2. **Transformation** - Data cleaning and feature engineering  
3. **Analytics** - Statistical analysis and insight generation

---

## Architecture

```
┌─────────────────┐
│   Data Sources  │
│  (CSV Files)    │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│         PHASE 1: INGESTION                  │
│  ┌──────────────────────────────────────┐   │
│  │  • Load CSV files                    │   │
│  │  • Validate schema                   │   │
│  │  • Check data quality                │   │
│  │  • Store metadata                    │   │
│  └──────────────────────────────────────┘   │
└────────┬────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│         PHASE 2: TRANSFORMATION             │
│  ┌──────────────────────────────────────┐   │
│  │  • Convert data types                │   │
│  │  • Handle missing values             │   │
│  │  • Create derived features           │   │
│  │  • Detect outliers                   │   │
│  │  • Aggregate user profiles           │   │
│  └──────────────────────────────────────┘   │
└────────┬────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│         PHASE 3: ANALYTICS                  │
│  ┌──────────────────────────────────────┐   │
│  │  • Statistical analysis              │   │
│  │  • Pattern detection                 │   │
│  │  • User clustering                   │   │
│  │  • Correlation analysis              │   │
│  │  • Insight generation                │   │
│  └──────────────────────────────────────┘   │
└────────┬────────────────────────────────────┘
         │
         ▼
┌─────────────────┐
│  Visualization  │
│  & Dashboards   │
└─────────────────┘
```

---

## Phase 1: Data Ingestion

### Purpose
Load and validate raw data from multiple sources.

### Supported Datasets

1. **Activity Data** (Primary)
   - Daily activity metrics
   - Steps, distance, calories
   - Activity minutes by intensity
   
2. **Sleep Data** (Optional)
   - Sleep duration
   - Sleep quality metrics
   - Time in bed vs. asleep
   
3. **Heart Rate Data** (Optional)
   - Continuous heart rate monitoring
   - Resting heart rate
   - Heart rate zones

### Class: `DataIngestion`

#### Methods

**`ingest_activity_data(filepath)`**
- Loads daily activity CSV file
- Validates required columns
- Returns success status and message

**`ingest_sleep_data(filepath)`**
- Loads sleep tracking data
- Stores metadata

**`ingest_heartrate_data(filepath)`**
- Loads heart rate time series data
- Handles high-frequency data

**`get_ingestion_summary()`**
- Returns summary of all ingested datasets
- Provides metadata for each dataset

### Validation Rules

- ✅ Required columns must be present
- ✅ Data types must be valid
- ✅ File size must be under 16MB
- ✅ CSV format must be valid

### Example Usage

```python
from data_pipeline import DataIngestion

ingestion = DataIngestion()
success, message = ingestion.ingest_activity_data('data.csv')

if success:
    summary = ingestion.get_ingestion_summary()
    print(f"Loaded {summary['total_datasets']} datasets")
```

---

## Phase 2: Data Transformation

### Purpose
Clean, process, and enrich data for analysis.

### Class: `DataTransformation`

#### Transformations Applied

1. **Date/Time Processing**
   - Convert ActivityDate to datetime
   - Extract day of week, month, week number
   - Add temporal features

2. **Derived Features**
   - `TotalMinutes` - Sum of all activity minutes
   - `ActivePercentage` - % of time spent active
   - `ActivityLevel` - Categorical classification
   - `CaloriesPerStep` - Efficiency metric
   - `DistancePerStep` - Stride length indicator

3. **Outlier Detection**
   - IQR method for steps and calories
   - Flag outliers without removing them
   - Preserve data integrity

4. **User Profiles**
   - Aggregate statistics per user
   - Mean, std, min, max for key metrics
   - Activity pattern summaries

#### Methods

**`transform_activity_data()`**
- Applies all transformations to activity data
- Logs each transformation step
- Returns success status

**`create_user_profiles()`**
- Aggregates data by user ID
- Creates statistical summaries
- Useful for user segmentation

**`get_transformation_summary()`**
- Returns log of all transformations
- Provides transformation metadata

### Example Usage

```python
from data_pipeline import DataTransformation

transformation = DataTransformation(ingestion.datasets)
transformation.transform_activity_data()
transformation.create_user_profiles()

transformed_data = transformation.transformed_data
```

---

## Phase 3: Analytics

### Purpose
Perform statistical analysis and generate actionable insights.

### Class: `DataAnalytics`

#### Analytics Performed

1. **Activity Pattern Analysis**
   - Daily activity statistics
   - Weekly trends
   - Activity level distribution
   - Correlation matrices

2. **User Clustering**
   - K-means clustering on user profiles
   - Standardized features
   - Cluster characteristics
   - User segmentation

3. **Insight Generation**
   - Automated insight discovery
   - Health recommendations
   - Activity pattern insights
   - Behavioral analysis

#### Methods

**`analyze_activity_patterns()`**
- Analyzes daily and weekly patterns
- Calculates correlations
- Returns pattern statistics

**`perform_clustering()`**
- Clusters users by activity patterns
- Uses scikit-learn K-means
- Returns cluster statistics

**`generate_insights()`**
- Generates actionable insights
- Provides recommendations
- Categorizes by type (warning, success, info)

**`get_summary_statistics()`**
- Comprehensive statistical summary
- Overview metrics
- Activity distributions

### Insight Types

| Type | Icon | Description |
|------|------|-------------|
| `warning` | ⚠️ | Areas needing attention |
| `success` | ✅ | Positive achievements |
| `info` | ℹ️ | Informational insights |

### Example Usage

```python
from data_pipeline import DataAnalytics

analytics = DataAnalytics(transformation.transformed_data)
patterns = analytics.analyze_activity_patterns()
clustering = analytics.perform_clustering()
insights = analytics.generate_insights()
```

---

## API Endpoints

### Pipeline Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/upload` | POST | Upload CSV and run full pipeline |
| `/api/pipeline-status` | GET | Get pipeline execution status |
| `/api/insights` | GET | Get AI-generated insights |
| `/api/clustering` | GET | Get user clustering results |

### Data Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/statistics` | GET | Get summary statistics |
| `/api/data-preview` | GET | Preview first 10 rows |

### Chart Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/charts/calories-vs-steps` | GET | Scatter plot data |
| `/api/charts/active-minutes-pie` | GET | Pie chart data |
| `/api/charts/weekly-activity` | GET | Bar chart data |
| `/api/charts/sedentary-minutes` | GET | Sedentary analysis |
| `/api/charts/calories-daily` | GET | Daily calories |

---

## Data Flow Example

### 1. User Uploads File

```javascript
// Frontend sends file
const formData = new FormData();
formData.append('file', file);
fetch('/api/upload', { method: 'POST', body: formData });
```

### 2. Backend Processes Through Pipeline

```python
# Phase 1: Ingestion
ingestion = DataIngestion()
ingestion.ingest_activity_data(filepath)

# Phase 2: Transformation
transformation = DataTransformation(ingestion.datasets)
transformation.transform_activity_data()
transformation.create_user_profiles()

# Phase 3: Analytics
analytics = DataAnalytics(transformation.transformed_data)
analytics.analyze_activity_patterns()
analytics.perform_clustering()
analytics.generate_insights()
```

### 3. Frontend Displays Results

```javascript
// Load pipeline status
const status = await fetch('/api/pipeline-status');

// Load insights
const insights = await fetch('/api/insights');

// Load charts
const charts = await Promise.all([
    fetch('/api/charts/calories-vs-steps'),
    fetch('/api/charts/active-minutes-pie'),
    // ... more charts
]);
```

---

## Features

### ✅ Implemented

- [x] Multi-dataset ingestion
- [x] Comprehensive data transformation
- [x] Statistical analysis
- [x] User clustering
- [x] Automated insight generation
- [x] Interactive visualizations
- [x] Real-time pipeline status
- [x] Error handling and validation

### 🚀 Future Enhancements

- [ ] Real-time data streaming
- [ ] Machine learning predictions
- [ ] Anomaly detection
- [ ] Sleep quality analysis
- [ ] Heart rate zone analysis
- [ ] Multi-user comparison
- [ ] Export reports (PDF/Excel)
- [ ] Data persistence (database)

---

## Performance

### Optimization Techniques

1. **Vectorized Operations**
   - Using pandas/numpy for speed
   - Avoiding Python loops
   
2. **Lazy Loading**
   - Load data only when needed
   - Cache transformed results

3. **Parallel Processing**
   - Multiple chart generation
   - Concurrent API calls

### Benchmarks

| Dataset Size | Ingestion | Transformation | Analytics | Total |
|--------------|-----------|----------------|-----------|-------|
| 100 rows     | <0.1s     | <0.2s          | <0.3s     | <0.6s |
| 1,000 rows   | <0.3s     | <0.5s          | <0.8s     | <1.6s |
| 10,000 rows  | <1.0s     | <2.0s          | <3.0s     | <6.0s |

---

## Error Handling

### Ingestion Errors
- Missing columns → Clear error message
- Invalid file format → Format validation
- File too large → Size limit check

### Transformation Errors
- Missing data → Graceful handling
- Invalid dates → Format conversion
- Outliers → Detection without removal

### Analytics Errors
- Insufficient data → Minimum requirements
- Clustering failure → Fallback to basic stats
- Insight generation → Partial results

---

## Best Practices

### For Users

1. **Data Quality**
   - Ensure CSV has all required columns
   - Use consistent date formats
   - Remove duplicate entries

2. **File Size**
   - Keep files under 16MB
   - Split large datasets if needed

3. **Data Privacy**
   - All processing is local
   - No data sent to external servers

### For Developers

1. **Code Organization**
   - Separate concerns (ingestion/transformation/analytics)
   - Use type hints
   - Document functions

2. **Testing**
   - Unit tests for each phase
   - Integration tests for pipeline
   - Sample data for testing

3. **Performance**
   - Profile slow operations
   - Use vectorized operations
   - Cache expensive computations

---

## Troubleshooting

### Pipeline Not Running

**Check:**
- File format is CSV
- Required columns present
- No syntax errors in data

**Solution:**
- Validate CSV structure
- Check terminal for errors
- Use sample data to test

### Insights Not Generating

**Check:**
- Data uploaded successfully
- Pipeline completed all phases
- Sufficient data for analysis

**Solution:**
- Refresh page and re-upload
- Check browser console
- Verify API endpoints

### Charts Not Loading

**Check:**
- Data transformation completed
- No JavaScript errors
- Network requests successful

**Solution:**
- Clear browser cache
- Check network tab in DevTools
- Verify chart endpoints

---

## Sample Data

### Activity Data Format

```csv
Id,ActivityDate,TotalSteps,TotalDistance,Calories,VeryActiveMinutes,FairlyActiveMinutes,LightlyActiveMinutes,SedentaryMinutes
1503960366,4/12/2016,13162,8.50,1985,25,13,328,728
```

### Sleep Data Format

```csv
Id,SleepDay,TotalSleepRecords,TotalMinutesAsleep,TotalTimeInBed
1503960366,4/12/2016,1,327,346
```

### Heart Rate Data Format

```csv
Id,Time,Value
1503960366,4/12/2016 7:21:00 AM,97
```

---

## Conclusion

This pipeline provides a robust, scalable solution for smartwatch data analysis. It handles the complete data lifecycle from ingestion to visualization, with built-in error handling and performance optimization.

**Key Benefits:**
- ✅ Automated processing
- ✅ Actionable insights
- ✅ Interactive visualizations
- ✅ Scalable architecture
- ✅ Easy to extend

For questions or issues, refer to the troubleshooting section or check the main README.md file.

