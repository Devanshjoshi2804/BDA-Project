# 📊 Dual Analytics Platform

A comprehensive data analytics platform with two distinct applications:
- **⌚ Smartwatch Fitness Analytics** (Port 5000)
- **📱 Phone Sensor Analytics** (Port 5001)

## 🌟 Features

### Complete Data Pipeline
1. **Ingestion** - Load and validate CSV data
2. **Transformation** - Clean, process, and enrich data
3. **Analytics** - Statistical analysis, clustering, and AI insights

### Interactive Visualizations
- Real-time charts and graphs
- Activity pattern analysis
- Calorie burn tracking
- Weekly trend analysis
- AI-powered insights

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation

1. **Install dependencies**:
```bash
pip install -r requirements.txt
```

### Running the Applications

#### Option 1: Run Both Applications (Recommended)
```bash
python run_both_apps.py
```
This will start both applications and open them in your browser:
- Smartwatch Analytics: http://localhost:5000
- Phone Sensor Analytics: http://localhost:5001

#### Option 2: Run Individually

**Smartwatch Analytics**:
```bash
python smartwatch_app.py
```
Access at: http://localhost:5000

**Phone Sensor Analytics**:
```bash
python phone_sensor_app.py
```
Access at: http://localhost:5001

## 📁 Project Structure

```
Smartwatch-Data-Analysis/
├── smartwatch_app.py           # Smartwatch analytics server
├── phone_sensor_app.py          # Phone sensor analytics server
├── run_both_apps.py             # Launch both applications
├── data_pipeline.py             # Data processing pipeline
├── requirements.txt             # Python dependencies
├── templates/
│   ├── smartwatch/
│   │   └── index.html          # Smartwatch UI (Fitness theme)
│   └── phone_sensor/
│       └── index.html          # Phone sensor UI (Tech theme)
├── static/
│   ├── smartwatch.js           # Smartwatch frontend logic
│   └── phone_sensor.js         # Phone sensor frontend logic
├── uploads/
│   ├── smartwatch/             # Uploaded smartwatch data
│   └── phone_sensor/           # Uploaded phone sensor data
├── sample_data.csv             # Sample activity data
├── sample_sleep_data.csv       # Sample sleep data
└── sample_heartrate_data.csv   # Sample heart rate data
```

## 📊 Data Format

### Activity Data (CSV)
Required columns:
- `Id` - User identifier
- `ActivityDate` - Date (format: M/D/YYYY)
- `TotalSteps` - Total steps taken
- `TotalDistance` - Distance covered
- `Calories` - Calories burned
- `VeryActiveMinutes` - High intensity activity
- `FairlyActiveMinutes` - Moderate activity
- `LightlyActiveMinutes` - Light activity
- `SedentaryMinutes` - Inactive time

### Sample Data
Use the included `sample_data.csv` to test the application.

## 🎨 UI Themes

### Smartwatch Analytics (Port 5000)
- **Theme**: Fitness & Health
- **Colors**: Purple gradient (#667eea to #764ba2)
- **Focus**: Activity tracking, fitness goals, health metrics
- **Style**: Bold, energetic, motivational

### Phone Sensor Analytics (Port 5001)
- **Theme**: Technology & Mobile
- **Colors**: Cyan to purple gradient (#06b6d4 to #8b5cf6)
- **Focus**: Sensor data, movement patterns, device analytics
- **Style**: Modern, sleek, tech-forward

## 🔄 Data Pipeline

### Phase 1: Ingestion
- Load CSV files
- Validate data structure
- Store metadata

### Phase 2: Transformation
- Convert data types
- Create derived features
- Detect outliers
- Generate user profiles

### Phase 3: Analytics
- Statistical analysis
- Pattern detection
- User clustering (K-means)
- AI-powered insights

## 📈 Visualizations

Both applications include:
1. **Scatter Plot** - Calories vs Steps correlation
2. **Pie Chart** - Activity time distribution
3. **Bar Chart** - Weekly activity patterns
4. **Pie Chart** - Sedentary time analysis
5. **Pie Chart** - Daily calorie distribution

## 🧠 AI Insights

The system automatically generates:
- Activity level recommendations
- Health warnings
- Behavioral patterns
- Personalized tips

## 🛠️ Technology Stack

**Backend:**
- Flask 3.0.0
- Pandas 2.1.4
- NumPy 1.26.4
- Plotly 5.18.0
- Scikit-learn 1.3.2
- SciPy 1.11.4
- Statsmodels 0.14.1

**Frontend:**
- HTML5
- CSS3 (Custom design)
- JavaScript (ES6+)
- Plotly.js

## 🔧 Configuration

### Ports
- Smartwatch App: 5000
- Phone Sensor App: 5001

### Upload Limits
- Maximum file size: 16MB
- Supported format: CSV

## 📝 Usage Guide

1. **Start Application(s)**
   - Run `python run_both_apps.py` for both
   - Or run individual apps

2. **Upload Data**
   - Drag and drop CSV file
   - Or click to browse

3. **View Analytics**
   - Pipeline status updates automatically
   - Charts load in real-time
   - Insights generated instantly

4. **Explore Insights**
   - Review AI-generated recommendations
   - Analyze weekly patterns
   - Track progress metrics

## 🐛 Troubleshooting

### Port Already in Use
If ports 5000 or 5001 are occupied, modify the port numbers in:
- `smartwatch_app.py` (line with `app.run()`)
- `phone_sensor_app.py` (line with `app.run()`)

### Module Not Found
Reinstall dependencies:
```bash
pip install --user -r requirements.txt
```

### CSV Upload Error
Ensure your CSV has all required columns and proper date format (M/D/YYYY).

## 🔒 Privacy & Security

- All processing happens locally
- No data sent to external servers
- Files stored temporarily in uploads folder
- No user tracking or analytics

## 📚 Documentation

- `PIPELINE_DOCUMENTATION.md` - Detailed pipeline architecture
- `README.md` - This file

## 🎯 Use Cases

### Smartwatch Analytics
- Personal fitness tracking
- Health monitoring
- Activity goal setting
- Workout analysis

### Phone Sensor Analytics
- Movement pattern analysis
- Location tracking insights
- Device usage patterns
- Behavioral analytics

## 🚀 Future Enhancements

- [ ] Real-time data streaming
- [ ] Machine learning predictions
- [ ] Multi-user comparison
- [ ] Export reports (PDF/Excel)
- [ ] Database integration
- [ ] Mobile app support

## 📄 License

Open source - Educational purposes

## 🙏 Acknowledgments

- Dataset: FitBit Fitness Tracker Data (Kaggle)
- Built with Flask, Plotly, and modern web technologies

---

**Happy Analyzing! 📊⌚📱**

For questions or issues, check the troubleshooting section or review the pipeline documentation.
