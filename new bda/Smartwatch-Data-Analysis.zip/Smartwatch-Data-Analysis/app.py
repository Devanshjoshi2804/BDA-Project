from flask import Flask, render_template, jsonify, request, send_from_directory
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import json
import os
from werkzeug.utils import secure_filename
from data_pipeline import DataIngestion, DataTransformation, DataAnalytics

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Global variables for pipeline
current_data = None
pipeline_ingestion = DataIngestion()
pipeline_transformation = None
pipeline_analytics = None

def load_data(filepath):
    """Load and preprocess the smartwatch data"""
    data = pd.read_csv(filepath)
    
    # Convert ActivityDate to datetime
    data["ActivityDate"] = pd.to_datetime(data["ActivityDate"], format="%m/%d/%Y")
    
    # Add TotalMinutes column
    data["TotalMinutes"] = (data["VeryActiveMinutes"] + 
                           data["FairlyActiveMinutes"] + 
                           data["LightlyActiveMinutes"] + 
                           data["SedentaryMinutes"])
    
    # Add Day column
    data["Day"] = data["ActivityDate"].dt.day_name()
    
    return data

def get_calories_vs_steps_chart(data):
    """Generate calories vs steps scatter plot"""
    figure = px.scatter(data_frame=data, x="Calories",
                       y="TotalSteps", size="VeryActiveMinutes", 
                       trendline="ols", 
                       title="Relationship between Calories & Total Steps")
    return json.loads(figure.to_json())

def get_active_minutes_pie_chart(data):
    """Generate pie chart for active minutes"""
    label = ["Very Active Minutes", "Fairly Active Minutes", 
             "Lightly Active Minutes", "Inactive Minutes"]
    counts = data[["VeryActiveMinutes", "FairlyActiveMinutes", 
                   "LightlyActiveMinutes", "SedentaryMinutes"]].mean()
    colors = ['gold', 'lightgreen', "pink", "blue"]
    
    fig = go.Figure(data=[go.Pie(labels=label, values=counts)])
    fig.update_layout(title_text='Average Total Active Minutes Per Day')
    fig.update_traces(hoverinfo='label+percent', textinfo='value+percent', 
                     textfont_size=14,
                     marker=dict(colors=colors, line=dict(color='black', width=2)))
    return json.loads(fig.to_json())

def get_weekly_activity_chart(data):
    """Generate weekly activity bar chart"""
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=data["Day"],
        y=data["VeryActiveMinutes"],
        name='Very Active',
        marker_color='purple'
    ))
    fig.add_trace(go.Bar(
        x=data["Day"],
        y=data["FairlyActiveMinutes"],
        name='Fairly Active',
        marker_color='green'
    ))
    fig.add_trace(go.Bar(
        x=data["Day"],
        y=data["LightlyActiveMinutes"],
        name='Lightly Active',
        marker_color='pink'
    ))
    fig.update_layout(barmode='group', xaxis_tickangle=-45,
                     title="Activity Minutes by Day of Week")
    return json.loads(fig.to_json())

def get_sedentary_minutes_chart(data):
    """Generate sedentary minutes pie chart"""
    day_counts = data.groupby("Day")["SedentaryMinutes"].sum()
    label = day_counts.index
    counts = day_counts.values
    colors = ['gold', 'lightgreen', "pink", "blue", "skyblue", "cyan", "orange"]
    
    fig = go.Figure(data=[go.Pie(labels=label, values=counts)])
    fig.update_layout(title_text='Inactive Minutes by Day of Week')
    fig.update_traces(hoverinfo='label+percent', textinfo='value+percent', 
                     textfont_size=14,
                     marker=dict(colors=colors, line=dict(color='black', width=2)))
    return json.loads(fig.to_json())

def get_calories_daily_chart(data):
    """Generate calories burned daily pie chart"""
    day_counts = data.groupby("Day")["Calories"].sum()
    label = day_counts.index
    counts = day_counts.values
    colors = ['gold', 'lightgreen', "pink", "blue", "skyblue", "cyan", "orange"]
    
    fig = go.Figure(data=[go.Pie(labels=label, values=counts)])
    fig.update_layout(title_text='Calories Burned by Day of Week')
    fig.update_traces(hoverinfo='label+percent', textinfo='value+percent', 
                     textfont_size=14,
                     marker=dict(colors=colors, line=dict(color='black', width=2)))
    return json.loads(fig.to_json())

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Handle file upload with pipeline processing"""
    global current_data, pipeline_ingestion, pipeline_transformation, pipeline_analytics
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Phase 1: Ingestion
            pipeline_ingestion = DataIngestion()
            success, message = pipeline_ingestion.ingest_activity_data(filepath)
            
            if not success:
                return jsonify({'error': message}), 400
            
            # Phase 2: Transformation
            pipeline_transformation = DataTransformation(pipeline_ingestion.datasets)
            pipeline_transformation.transform_activity_data()
            pipeline_transformation.create_user_profiles()
            
            # Phase 3: Analytics
            pipeline_analytics = DataAnalytics(pipeline_transformation.transformed_data)
            pipeline_analytics.analyze_activity_patterns()
            pipeline_analytics.perform_clustering()
            pipeline_analytics.generate_insights()
            
            # Load data for backward compatibility
            current_data = pipeline_transformation.transformed_data['activity']
            
            return jsonify({
                'success': True,
                'message': 'File uploaded and processed through pipeline successfully',
                'rows': len(current_data),
                'columns': len(current_data.columns),
                'pipeline_status': {
                    'ingestion': 'completed',
                    'transformation': 'completed',
                    'analytics': 'completed'
                }
            })
        except Exception as e:
            return jsonify({'error': f'Error processing file: {str(e)}'}), 400
    
    return jsonify({'error': 'Invalid file format. Please upload a CSV file.'}), 400

@app.route('/api/statistics')
def get_statistics():
    """Get basic statistics"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    stats = {
        'total_records': len(current_data),
        'unique_users': current_data['Id'].nunique(),
        'date_range': {
            'start': current_data['ActivityDate'].min().strftime('%Y-%m-%d'),
            'end': current_data['ActivityDate'].max().strftime('%Y-%m-%d')
        },
        'averages': {
            'total_steps': round(current_data['TotalSteps'].mean(), 2),
            'total_distance': round(current_data['TotalDistance'].mean(), 2),
            'calories': round(current_data['Calories'].mean(), 2),
            'very_active_minutes': round(current_data['VeryActiveMinutes'].mean(), 2),
            'fairly_active_minutes': round(current_data['FairlyActiveMinutes'].mean(), 2),
            'lightly_active_minutes': round(current_data['LightlyActiveMinutes'].mean(), 2),
            'sedentary_minutes': round(current_data['SedentaryMinutes'].mean(), 2)
        }
    }
    
    return jsonify(stats)

@app.route('/api/charts/calories-vs-steps')
def calories_vs_steps():
    """Get calories vs steps chart"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    try:
        chart_data = get_calories_vs_steps_chart(current_data)
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': f'Error generating chart: {str(e)}'}), 500

@app.route('/api/charts/active-minutes-pie')
def active_minutes_pie():
    """Get active minutes pie chart"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    try:
        chart_data = get_active_minutes_pie_chart(current_data)
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': f'Error generating chart: {str(e)}'}), 500

@app.route('/api/charts/weekly-activity')
def weekly_activity():
    """Get weekly activity chart"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    try:
        chart_data = get_weekly_activity_chart(current_data)
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': f'Error generating chart: {str(e)}'}), 500

@app.route('/api/charts/sedentary-minutes')
def sedentary_minutes():
    """Get sedentary minutes chart"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    try:
        chart_data = get_sedentary_minutes_chart(current_data)
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': f'Error generating chart: {str(e)}'}), 500

@app.route('/api/charts/calories-daily')
def calories_daily():
    """Get calories daily chart"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    try:
        chart_data = get_calories_daily_chart(current_data)
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': f'Error generating chart: {str(e)}'}), 500

@app.route('/api/data-preview')
def data_preview():
    """Get a preview of the data"""
    global current_data
    
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    # Convert datetime to string for JSON serialization
    preview_data = current_data.head(10).copy()
    preview_data['ActivityDate'] = preview_data['ActivityDate'].dt.strftime('%Y-%m-%d')
    
    return jsonify({
        'columns': list(preview_data.columns),
        'data': preview_data.to_dict('records')
    })

@app.route('/api/insights')
def get_insights():
    """Get AI-generated insights"""
    global pipeline_analytics
    
    if pipeline_analytics is None:
        return jsonify({'error': 'No analytics available. Please upload data first.'}), 400
    
    try:
        insights = pipeline_analytics.generate_insights()
        return jsonify({'insights': insights})
    except Exception as e:
        return jsonify({'error': f'Error generating insights: {str(e)}'}), 500

@app.route('/api/clustering')
def get_clustering():
    """Get user clustering results"""
    global pipeline_analytics
    
    if pipeline_analytics is None:
        return jsonify({'error': 'No analytics available. Please upload data first.'}), 400
    
    try:
        clustering = pipeline_analytics.analytics_results.get('clustering', {})
        return jsonify(clustering)
    except Exception as e:
        return jsonify({'error': f'Error getting clustering: {str(e)}'}), 500

@app.route('/api/pipeline-status')
def get_pipeline_status():
    """Get pipeline processing status"""
    global pipeline_ingestion, pipeline_transformation, pipeline_analytics
    
    status = {
        'ingestion': {
            'completed': pipeline_ingestion is not None and len(pipeline_ingestion.datasets) > 0,
            'datasets': list(pipeline_ingestion.datasets.keys()) if pipeline_ingestion else [],
            'metadata': pipeline_ingestion.metadata if pipeline_ingestion else {}
        },
        'transformation': {
            'completed': pipeline_transformation is not None,
            'log': pipeline_transformation.transformation_log if pipeline_transformation else []
        },
        'analytics': {
            'completed': pipeline_analytics is not None,
            'results_available': list(pipeline_analytics.analytics_results.keys()) if pipeline_analytics else []
        }
    }
    
    return jsonify(status)

if __name__ == '__main__':
    import sys
    import io
    
    # Fix encoding for Windows console
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    print("\n" + "="*60)
    print("Smartwatch Data Analysis Application")
    print("="*60)
    print("\nServer starting...")
    print("Open your browser and navigate to: http://localhost:5000")
    print("\nInstructions:")
    print("   1. Upload your Fitbit CSV file")
    print("   2. View interactive visualizations and statistics")
    print("\nPress CTRL+C to stop the server\n")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)

