"""
Data Pipeline for Smartwatch Analysis
Handles: Ingestion -> Transformation -> Analytics
"""

import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')


class DataIngestion:
    """
    Phase 1: Data Ingestion
    Loads and validates multiple datasets
    """
    
    def __init__(self):
        self.datasets = {}
        self.metadata = {}
    
    def ingest_activity_data(self, filepath):
        """Ingest daily activity data"""
        try:
            data = pd.read_csv(filepath)
            
            # Validate required columns
            required_cols = ['Id', 'ActivityDate', 'TotalSteps', 'TotalDistance', 
                           'Calories', 'VeryActiveMinutes', 'FairlyActiveMinutes',
                           'LightlyActiveMinutes', 'SedentaryMinutes']
            
            missing_cols = [col for col in required_cols if col not in data.columns]
            if missing_cols:
                raise ValueError(f"Missing columns: {missing_cols}")
            
            self.datasets['activity'] = data
            self.metadata['activity'] = {
                'rows': len(data),
                'columns': len(data.columns),
                'users': data['Id'].nunique(),
                'ingestion_time': datetime.now().isoformat()
            }
            
            return True, "Activity data ingested successfully"
        except Exception as e:
            return False, f"Error ingesting activity data: {str(e)}"
    
    def ingest_sleep_data(self, filepath):
        """Ingest sleep data"""
        try:
            data = pd.read_csv(filepath)
            self.datasets['sleep'] = data
            self.metadata['sleep'] = {
                'rows': len(data),
                'columns': len(data.columns),
                'ingestion_time': datetime.now().isoformat()
            }
            return True, "Sleep data ingested successfully"
        except Exception as e:
            return False, f"Error ingesting sleep data: {str(e)}"
    
    def ingest_heartrate_data(self, filepath):
        """Ingest heart rate data"""
        try:
            data = pd.read_csv(filepath)
            self.datasets['heartrate'] = data
            self.metadata['heartrate'] = {
                'rows': len(data),
                'columns': len(data.columns),
                'ingestion_time': datetime.now().isoformat()
            }
            return True, "Heart rate data ingested successfully"
        except Exception as e:
            return False, f"Error ingesting heart rate data: {str(e)}"
    
    def get_ingestion_summary(self):
        """Get summary of ingested data"""
        return {
            'datasets_loaded': list(self.datasets.keys()),
            'metadata': self.metadata,
            'total_datasets': len(self.datasets)
        }


class DataTransformation:
    """
    Phase 2: Data Transformation
    Cleans, processes, and enriches data
    """
    
    def __init__(self, datasets):
        self.raw_data = datasets
        self.transformed_data = {}
        self.transformation_log = []
    
    def transform_activity_data(self):
        """Transform activity data"""
        if 'activity' not in self.raw_data:
            return False, "Activity data not found"
        
        try:
            data = self.raw_data['activity'].copy()
            
            # Convert date
            data['ActivityDate'] = pd.to_datetime(data['ActivityDate'], format="%m/%d/%Y")
            self.transformation_log.append("Converted ActivityDate to datetime")
            
            # Add derived features
            data['Day'] = data['ActivityDate'].dt.day_name()
            data['DayOfWeek'] = data['ActivityDate'].dt.dayofweek
            data['Month'] = data['ActivityDate'].dt.month
            data['Week'] = data['ActivityDate'].dt.isocalendar().week
            self.transformation_log.append("Added temporal features")
            
            # Calculate total active minutes
            data['TotalMinutes'] = (data['VeryActiveMinutes'] + 
                                   data['FairlyActiveMinutes'] + 
                                   data['LightlyActiveMinutes'] + 
                                   data['SedentaryMinutes'])
            
            # Calculate active percentage
            data['ActivePercentage'] = ((data['VeryActiveMinutes'] + 
                                        data['FairlyActiveMinutes'] + 
                                        data['LightlyActiveMinutes']) / 
                                       data['TotalMinutes'] * 100)
            
            # Activity level classification
            data['ActivityLevel'] = pd.cut(data['TotalSteps'], 
                                          bins=[0, 5000, 10000, 15000, float('inf')],
                                          labels=['Sedentary', 'Lightly Active', 
                                                 'Active', 'Very Active'])
            
            # Calorie burn efficiency
            data['CaloriesPerStep'] = data['Calories'] / (data['TotalSteps'] + 1)
            
            # Distance per step (stride length indicator)
            data['DistancePerStep'] = data['TotalDistance'] / (data['TotalSteps'] + 1)
            
            self.transformation_log.append("Added calculated features")
            
            # Handle outliers (IQR method)
            for col in ['TotalSteps', 'Calories']:
                Q1 = data[col].quantile(0.25)
                Q3 = data[col].quantile(0.75)
                IQR = Q3 - Q1
                data[f'{col}_Outlier'] = ((data[col] < (Q1 - 1.5 * IQR)) | 
                                          (data[col] > (Q3 + 1.5 * IQR)))
            
            self.transformation_log.append("Detected outliers")
            
            self.transformed_data['activity'] = data
            return True, "Activity data transformed successfully"
            
        except Exception as e:
            return False, f"Error transforming activity data: {str(e)}"
    
    def create_user_profiles(self):
        """Create aggregated user profiles"""
        if 'activity' not in self.transformed_data:
            return False, "Transformed activity data not found"
        
        try:
            data = self.transformed_data['activity']
            
            user_profiles = data.groupby('Id').agg({
                'TotalSteps': ['mean', 'std', 'min', 'max'],
                'Calories': ['mean', 'std', 'min', 'max'],
                'TotalDistance': ['mean', 'sum'],
                'VeryActiveMinutes': 'mean',
                'FairlyActiveMinutes': 'mean',
                'LightlyActiveMinutes': 'mean',
                'SedentaryMinutes': 'mean',
                'ActivePercentage': 'mean'
            }).round(2)
            
            user_profiles.columns = ['_'.join(col).strip() for col in user_profiles.columns.values]
            user_profiles = user_profiles.reset_index()
            
            self.transformed_data['user_profiles'] = user_profiles
            self.transformation_log.append("Created user profiles")
            
            return True, "User profiles created successfully"
            
        except Exception as e:
            return False, f"Error creating user profiles: {str(e)}"
    
    def get_transformation_summary(self):
        """Get transformation summary"""
        return {
            'transformed_datasets': list(self.transformed_data.keys()),
            'transformation_log': self.transformation_log,
            'total_transformations': len(self.transformation_log)
        }


class DataAnalytics:
    """
    Phase 3: Analytics and Insights
    Performs statistical analysis and generates insights
    """
    
    def __init__(self, transformed_data):
        self.data = transformed_data
        self.analytics_results = {}
    
    def analyze_activity_patterns(self):
        """Analyze activity patterns"""
        if 'activity' not in self.data:
            return {}
        
        data = self.data['activity']
        
        # Daily patterns
        daily_stats = data.groupby('Day').agg({
            'TotalSteps': 'mean',
            'Calories': 'mean',
            'VeryActiveMinutes': 'mean',
            'SedentaryMinutes': 'mean'
        }).round(2)
        
        # Weekly trends
        weekly_stats = data.groupby('Week').agg({
            'TotalSteps': 'mean',
            'Calories': 'mean',
            'ActivePercentage': 'mean'
        }).round(2)
        
        # Activity level distribution
        activity_distribution = data['ActivityLevel'].value_counts().to_dict()
        
        # Correlation analysis
        correlation_matrix = data[['TotalSteps', 'Calories', 'TotalDistance', 
                                   'VeryActiveMinutes', 'ActivePercentage']].corr().round(3)
        
        self.analytics_results['activity_patterns'] = {
            'daily_stats': daily_stats.to_dict(),
            'weekly_stats': weekly_stats.to_dict(),
            'activity_distribution': activity_distribution,
            'correlations': correlation_matrix.to_dict()
        }
        
        return self.analytics_results['activity_patterns']
    
    def perform_clustering(self):
        """Perform user clustering based on activity patterns"""
        if 'user_profiles' not in self.data:
            return {}
        
        try:
            profiles = self.data['user_profiles']
            
            # Select features for clustering
            features = ['TotalSteps_mean', 'Calories_mean', 'VeryActiveMinutes_mean',
                       'SedentaryMinutes_mean', 'ActivePercentage_mean']
            
            X = profiles[features].fillna(0)
            
            # Standardize features
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            # Perform K-means clustering
            n_clusters = min(3, len(profiles))
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            profiles['Cluster'] = kmeans.fit_predict(X_scaled)
            
            # Cluster characteristics
            cluster_stats = profiles.groupby('Cluster')[features].mean().round(2)
            
            self.analytics_results['clustering'] = {
                'n_clusters': n_clusters,
                'cluster_stats': cluster_stats.to_dict(),
                'cluster_distribution': profiles['Cluster'].value_counts().to_dict()
            }
            
            self.data['user_profiles'] = profiles
            
            return self.analytics_results['clustering']
            
        except Exception as e:
            return {'error': str(e)}
    
    def generate_insights(self):
        """Generate actionable insights"""
        if 'activity' not in self.data:
            return []
        
        data = self.data['activity']
        insights = []
        
        # Average steps insight
        avg_steps = data['TotalSteps'].mean()
        if avg_steps < 5000:
            insights.append({
                'type': 'warning',
                'category': 'Activity',
                'message': f'Average daily steps ({avg_steps:.0f}) is below recommended 10,000 steps',
                'recommendation': 'Increase daily walking activity'
            })
        elif avg_steps >= 10000:
            insights.append({
                'type': 'success',
                'category': 'Activity',
                'message': f'Great! Average daily steps ({avg_steps:.0f}) meets recommended goal',
                'recommendation': 'Maintain current activity level'
            })
        
        # Sedentary time insight
        avg_sedentary = data['SedentaryMinutes'].mean()
        if avg_sedentary > 600:  # More than 10 hours
            insights.append({
                'type': 'warning',
                'category': 'Sedentary Behavior',
                'message': f'High sedentary time ({avg_sedentary:.0f} minutes/day)',
                'recommendation': 'Take regular breaks and move every hour'
            })
        
        # Active percentage insight
        avg_active_pct = data['ActivePercentage'].mean()
        if avg_active_pct < 20:
            insights.append({
                'type': 'info',
                'category': 'Activity Level',
                'message': f'Only {avg_active_pct:.1f}% of time is spent in active movement',
                'recommendation': 'Aim for at least 30 minutes of moderate activity daily'
            })
        
        # Most active day
        most_active_day = data.groupby('Day')['TotalSteps'].mean().idxmax()
        insights.append({
            'type': 'info',
            'category': 'Weekly Pattern',
            'message': f'{most_active_day} is your most active day',
            'recommendation': 'Try to replicate this activity level on other days'
        })
        
        # Calorie efficiency
        avg_cal_per_step = data['CaloriesPerStep'].mean()
        insights.append({
            'type': 'info',
            'category': 'Efficiency',
            'message': f'Average calorie burn: {avg_cal_per_step:.3f} calories per step',
            'recommendation': 'Higher intensity activities burn more calories per step'
        })
        
        self.analytics_results['insights'] = insights
        return insights
    
    def get_summary_statistics(self):
        """Get comprehensive summary statistics"""
        if 'activity' not in self.data:
            return {}
        
        data = self.data['activity']
        
        summary = {
            'overview': {
                'total_records': len(data),
                'unique_users': data['Id'].nunique(),
                'date_range': {
                    'start': data['ActivityDate'].min().strftime('%Y-%m-%d'),
                    'end': data['ActivityDate'].max().strftime('%Y-%m-%d'),
                    'days': (data['ActivityDate'].max() - data['ActivityDate'].min()).days
                }
            },
            'activity_metrics': {
                'avg_steps': round(data['TotalSteps'].mean(), 2),
                'avg_distance': round(data['TotalDistance'].mean(), 2),
                'avg_calories': round(data['Calories'].mean(), 2),
                'avg_active_minutes': round(data['VeryActiveMinutes'].mean() + 
                                           data['FairlyActiveMinutes'].mean() + 
                                           data['LightlyActiveMinutes'].mean(), 2),
                'avg_sedentary_minutes': round(data['SedentaryMinutes'].mean(), 2)
            },
            'activity_distribution': {
                'very_active_pct': round(data['VeryActiveMinutes'].mean() / 
                                        data['TotalMinutes'].mean() * 100, 2),
                'fairly_active_pct': round(data['FairlyActiveMinutes'].mean() / 
                                          data['TotalMinutes'].mean() * 100, 2),
                'lightly_active_pct': round(data['LightlyActiveMinutes'].mean() / 
                                           data['TotalMinutes'].mean() * 100, 2),
                'sedentary_pct': round(data['SedentaryMinutes'].mean() / 
                                      data['TotalMinutes'].mean() * 100, 2)
            }
        }
        
        self.analytics_results['summary'] = summary
        return summary

