"""
Launcher script to run both applications simultaneously
"""

import subprocess
import sys
import time
import webbrowser
from threading import Thread
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def run_smartwatch_app():
    """Run smartwatch app on port 5000"""
    subprocess.run([sys.executable, 'smartwatch_app.py'])

def run_phone_sensor_app():
    """Run phone sensor app on port 5001"""
    subprocess.run([sys.executable, 'phone_sensor_app.py'])

def open_browsers():
    """Open both applications in browser after a delay"""
    time.sleep(3)  # Wait for servers to start
    webbrowser.open('http://localhost:5000')
    time.sleep(1)
    webbrowser.open('http://localhost:5001')

if __name__ == '__main__':
    print("\n" + "="*70)
    print("Starting Both Applications")
    print("="*70)
    print("\nSmartwatch Analytics: http://localhost:5000")
    print("Phone Sensor Analytics: http://localhost:5001")
    print("\nPress CTRL+C to stop both servers\n")
    print("="*70 + "\n")

    # Start browser opener thread
    browser_thread = Thread(target=open_browsers, daemon=True)
    browser_thread.start()

    # Start both apps in separate threads
    smartwatch_thread = Thread(target=run_smartwatch_app, daemon=True)
    phone_sensor_thread = Thread(target=run_phone_sensor_app, daemon=True)

    smartwatch_thread.start()
    phone_sensor_thread.start()

    try:
        # Keep main thread alive
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n" + "="*70)
        print("Shutting down both applications...")
        print("="*70 + "\n")
        sys.exit(0)

