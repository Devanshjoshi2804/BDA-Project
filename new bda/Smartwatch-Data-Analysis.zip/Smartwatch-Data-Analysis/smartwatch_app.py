"""
Smartwatch Analytics Application
Port: 5000
Focus: Fitness tracking, activity monitoring, health metrics
"""

from flask import Flask, render_template, jsonify, request
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import json
import os
from werkzeug.utils import secure_filename
from data_pipeline import DataIngestion, DataTransformation, DataAnalytics

app = Flask(__name__, template_folder='templates/smartwatch')
app.config['UPLOAD_FOLDER'] = 'uploads/smartwatch'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Global variables
current_data = None
pipeline_ingestion = DataIngestion()
pipeline_transformation = None
pipeline_analytics = None

def load_data(filepath):
    data = pd.read_csv(filepath)
    data["ActivityDate"] = pd.to_datetime(data["ActivityDate"], format="%m/%d/%Y")
    data["TotalMinutes"] = (data["VeryActiveMinutes"] + data["FairlyActiveMinutes"] + 
                           data["LightlyActiveMinutes"] + data["SedentaryMinutes"])
    data["Day"] = data["ActivityDate"].dt.day_name()
    return data

def get_calories_vs_steps_chart(data):
    figure = px.scatter(data_frame=data, x="Calories", y="TotalSteps", 
                       size="VeryActiveMinutes", trendline="ols",
                       title="Calories vs Steps Correlation")
    return json.loads(figure.to_json())

def get_active_minutes_pie_chart(data):
    label = ["Very Active", "Fairly Active", "Lightly Active", "Sedentary"]
    counts = data[["VeryActiveMinutes", "FairlyActiveMinutes", 
                   "LightlyActiveMinutes", "SedentaryMinutes"]].mean()
    colors = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444']
    
    fig = go.Figure(data=[go.Pie(labels=label, values=counts)])
    fig.update_layout(title_text='Activity Distribution')
    fig.update_traces(marker=dict(colors=colors))
    return json.loads(fig.to_json())

def get_weekly_activity_chart(data):
    fig = go.Figure()
    fig.add_trace(go.Bar(x=data["Day"], y=data["VeryActiveMinutes"],
                        name='Very Active', marker_color='#10b981'))
    fig.add_trace(go.Bar(x=data["Day"], y=data["FairlyActiveMinutes"],
                        name='Fairly Active', marker_color='#3b82f6'))
    fig.add_trace(go.Bar(x=data["Day"], y=data["LightlyActiveMinutes"],
                        name='Lightly Active', marker_color='#f59e0b'))
    fig.update_layout(barmode='group', title="Weekly Activity Pattern")
    return json.loads(fig.to_json())

def get_sedentary_minutes_chart(data):
    day_counts = data.groupby("Day")["SedentaryMinutes"].sum()
    colors = ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4']
    
    fig = go.Figure(data=[go.Pie(labels=day_counts.index, values=day_counts.values)])
    fig.update_layout(title_text='Sedentary Time by Day')
    fig.update_traces(marker=dict(colors=colors))
    return json.loads(fig.to_json())

def get_calories_daily_chart(data):
    day_counts = data.groupby("Day")["Calories"].sum()
    colors = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4']
    
    fig = go.Figure(data=[go.Pie(labels=day_counts.index, values=day_counts.values)])
    fig.update_layout(title_text='Calories Burned by Day')
    fig.update_traces(marker=dict(colors=colors))
    return json.loads(fig.to_json())

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    global current_data, pipeline_ingestion, pipeline_transformation, pipeline_analytics
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '' or not file.filename.endswith('.csv'):
        return jsonify({'error': 'Invalid file'}), 400
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    try:
        pipeline_ingestion = DataIngestion()
        success, message = pipeline_ingestion.ingest_activity_data(filepath)
        
        if not success:
            return jsonify({'error': message}), 400
        
        pipeline_transformation = DataTransformation(pipeline_ingestion.datasets)
        pipeline_transformation.transform_activity_data()
        pipeline_transformation.create_user_profiles()
        
        pipeline_analytics = DataAnalytics(pipeline_transformation.transformed_data)
        pipeline_analytics.analyze_activity_patterns()
        pipeline_analytics.perform_clustering()
        pipeline_analytics.generate_insights()
        
        current_data = pipeline_transformation.transformed_data['activity']
        
        return jsonify({
            'success': True,
            'message': 'Smartwatch data processed successfully',
            'rows': len(current_data),
            'columns': len(current_data.columns)
        })
    except Exception as e:
        return jsonify({'error': f'Error: {str(e)}'}), 400

@app.route('/api/statistics')
def get_statistics():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    stats = {
        'total_records': len(current_data),
        'unique_users': current_data['Id'].nunique(),
        'date_range': {
            'start': current_data['ActivityDate'].min().strftime('%Y-%m-%d'),
            'end': current_data['ActivityDate'].max().strftime('%Y-%m-%d')
        },
        'averages': {
            'total_steps': round(current_data['TotalSteps'].mean(), 2),
            'total_distance': round(current_data['TotalDistance'].mean(), 2),
            'calories': round(current_data['Calories'].mean(), 2),
            'very_active_minutes': round(current_data['VeryActiveMinutes'].mean(), 2),
            'fairly_active_minutes': round(current_data['FairlyActiveMinutes'].mean(), 2),
            'lightly_active_minutes': round(current_data['LightlyActiveMinutes'].mean(), 2),
            'sedentary_minutes': round(current_data['SedentaryMinutes'].mean(), 2)
        }
    }
    return jsonify(stats)

@app.route('/api/charts/calories-vs-steps')
def calories_vs_steps():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    try:
        return jsonify(get_calories_vs_steps_chart(current_data))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/charts/active-minutes-pie')
def active_minutes_pie():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    try:
        return jsonify(get_active_minutes_pie_chart(current_data))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/charts/weekly-activity')
def weekly_activity():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    try:
        return jsonify(get_weekly_activity_chart(current_data))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/charts/sedentary-minutes')
def sedentary_minutes():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    try:
        return jsonify(get_sedentary_minutes_chart(current_data))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/charts/calories-daily')
def calories_daily():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    try:
        return jsonify(get_calories_daily_chart(current_data))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/insights')
def get_insights():
    global pipeline_analytics
    if pipeline_analytics is None:
        return jsonify({'error': 'No analytics available'}), 400
    try:
        insights = pipeline_analytics.generate_insights()
        return jsonify({'insights': insights})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/pipeline-status')
def get_pipeline_status():
    global pipeline_ingestion, pipeline_transformation, pipeline_analytics
    
    status = {
        'ingestion': {
            'completed': pipeline_ingestion is not None and len(pipeline_ingestion.datasets) > 0,
            'datasets': list(pipeline_ingestion.datasets.keys()) if pipeline_ingestion else [],
            'metadata': pipeline_ingestion.metadata if pipeline_ingestion else {}
        },
        'transformation': {
            'completed': pipeline_transformation is not None,
            'log': pipeline_transformation.transformation_log if pipeline_transformation else []
        },
        'analytics': {
            'completed': pipeline_analytics is not None,
            'results_available': list(pipeline_analytics.analytics_results.keys()) if pipeline_analytics else []
        }
    }
    return jsonify(status)

@app.route('/api/data-preview')
def data_preview():
    global current_data
    if current_data is None:
        return jsonify({'error': 'No data loaded'}), 400
    
    preview_data = current_data.head(10).copy()
    preview_data['ActivityDate'] = preview_data['ActivityDate'].dt.strftime('%Y-%m-%d')
    
    return jsonify({
        'columns': list(preview_data.columns),
        'data': preview_data.to_dict('records')
    })

if __name__ == '__main__':
    import sys
    import io
    
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    print("\n" + "="*60)
    print("⌚ Smartwatch Analytics Application")
    print("="*60)
    print("\nServer starting on PORT 5000...")
    print("Open: http://localhost:5000")
    print("\nPress CTRL+C to stop\n")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)

