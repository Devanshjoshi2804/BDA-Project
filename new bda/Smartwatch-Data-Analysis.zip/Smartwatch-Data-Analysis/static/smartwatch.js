// Smartwatch Analytics JavaScript
const uploadZone = document.getElementById('upload-zone');
const fileInput = document.getElementById('file-input');
const successAlert = document.getElementById('success-alert');
const errorAlert = document.getElementById('error-alert');
const content = document.getElementById('content');
const loading = document.getElementById('loading');

// Drag and drop
uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'rgba(255, 255, 255, 0.6)';
});

uploadZone.addEventListener('dragleave', () => {
    uploadZone.style.borderColor = 'rgba(255, 255, 255, 0.3)';
});

uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'rgba(255, 255, 255, 0.3)';
    if (e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
    }
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleFile(e.target.files[0]);
    }
});

function showSuccess(message) {
    successAlert.textContent = message;
    successAlert.style.display = 'block';
    errorAlert.style.display = 'none';
    setTimeout(() => successAlert.style.display = 'none', 5000);
}

function showError(message) {
    errorAlert.textContent = message;
    errorAlert.style.display = 'block';
    successAlert.style.display = 'none';
    setTimeout(() => errorAlert.style.display = 'none', 5000);
}

async function handleFile(file) {
    if (!file.name.endsWith('.csv')) {
        showError('Please upload a CSV file');
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    loading.classList.remove('hidden');
    content.classList.add('hidden');

    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (response.ok) {
            showSuccess(`✓ Success! ${result.rows} records analyzed`);
            await loadDashboard();
        } else {
            showError(result.error || 'Error uploading file');
            loading.classList.add('hidden');
        }
    } catch (error) {
        showError('Error: ' + error.message);
        loading.classList.add('hidden');
    }
}

async function loadDashboard() {
    try {
        await updatePipeline();
        await loadStats();
        await loadInsights();
        await Promise.all([
            loadChart('/api/charts/calories-vs-steps', 'chart1'),
            loadChart('/api/charts/active-minutes-pie', 'chart2'),
            loadChart('/api/charts/weekly-activity', 'chart3'),
            loadChart('/api/charts/sedentary-minutes', 'chart4'),
            loadChart('/api/charts/calories-daily', 'chart5')
        ]);
        await loadPreview();

        loading.classList.add('hidden');
        content.classList.remove('hidden');
    } catch (error) {
        showError('Error loading dashboard: ' + error.message);
        loading.classList.add('hidden');
    }
}

async function updatePipeline() {
    const response = await fetch('/api/pipeline-status');
    const status = await response.json();

    if (status.ingestion.completed) {
        document.getElementById('stage-1').classList.add('completed');
        document.getElementById('status-1').textContent = `✓ ${status.ingestion.datasets.length} dataset(s) loaded`;
    }

    if (status.transformation.completed) {
        document.getElementById('stage-2').classList.add('completed');
        document.getElementById('status-2').textContent = `✓ ${status.transformation.log.length} transformations`;
    }

    if (status.analytics.completed) {
        document.getElementById('stage-3').classList.add('completed');
        document.getElementById('status-3').textContent = `✓ ${status.analytics.results_available.length} analyses`;
    }
}

async function loadStats() {
    const response = await fetch('/api/statistics');
    const stats = await response.json();

    document.getElementById('stats-grid').innerHTML = `
        <div class="stat-box">
            <div class="stat-icon">📊</div>
            <div class="stat-value">${stats.total_records}</div>
            <div class="stat-label">Total Records</div>
        </div>
        <div class="stat-box">
            <div class="stat-icon">👤</div>
            <div class="stat-value">${stats.unique_users}</div>
            <div class="stat-label">Users</div>
        </div>
        <div class="stat-box">
            <div class="stat-icon">👣</div>
            <div class="stat-value">${Math.round(stats.averages.total_steps).toLocaleString()}</div>
            <div class="stat-label">Avg Steps</div>
        </div>
        <div class="stat-box">
            <div class="stat-icon">🔥</div>
            <div class="stat-value">${Math.round(stats.averages.calories)}</div>
            <div class="stat-label">Avg Calories</div>
        </div>
        <div class="stat-box">
            <div class="stat-icon">📏</div>
            <div class="stat-value">${stats.averages.total_distance.toFixed(1)}</div>
            <div class="stat-label">Avg Distance (km)</div>
        </div>
        <div class="stat-box">
            <div class="stat-icon">⚡</div>
            <div class="stat-value">${Math.round(stats.averages.very_active_minutes)}</div>
            <div class="stat-label">Active Minutes</div>
        </div>
    `;
}

async function loadInsights() {
    const response = await fetch('/api/insights');
    const data = await response.json();

    if (data.insights && data.insights.length > 0) {
        const container = document.getElementById('insights-container');
        container.innerHTML = '';

        data.insights.forEach(insight => {
            const icons = { 'warning': '⚠️', 'success': '✅', 'info': 'ℹ️' };
            const card = document.createElement('div');
            card.className = `insight-item ${insight.type}`;
            card.innerHTML = `
                <div class="insight-icon">${icons[insight.type]}</div>
                <div class="insight-text">
                    <h4>${insight.category}</h4>
                    <p>${insight.message}</p>
                    <p><strong>💡 Recommendation:</strong> ${insight.recommendation}</p>
                </div>
            `;
            container.appendChild(card);
        });
    }
}

async function loadChart(endpoint, elementId) {
    try {
        const response = await fetch(endpoint);
        const chartData = await response.json();

        if (chartData.error) {
            document.getElementById(elementId).innerHTML = 
                `<div style="padding: 40px; text-align: center; color: #fca5a5;">Error: ${chartData.error}</div>`;
            return;
        }

        chartData.layout = {
            ...chartData.layout,
            paper_bgcolor: 'rgba(0,0,0,0)',
            plot_bgcolor: 'rgba(0,0,0,0)',
            font: { color: '#fff' },
            xaxis: { ...chartData.layout.xaxis, gridcolor: 'rgba(255,255,255,0.1)' },
            yaxis: { ...chartData.layout.yaxis, gridcolor: 'rgba(255,255,255,0.1)' }
        };

        Plotly.newPlot(elementId, chartData.data, chartData.layout, {responsive: true});
    } catch (error) {
        document.getElementById(elementId).innerHTML = 
            `<div style="padding: 40px; text-align: center; color: #fca5a5;">Error: ${error.message}</div>`;
    }
}

async function loadPreview() {
    const response = await fetch('/api/data-preview');
    const data = await response.json();

    let tableHTML = '<table class="data-table"><thead><tr>';
    data.columns.slice(0, 8).forEach(col => {
        tableHTML += `<th>${col}</th>`;
    });
    tableHTML += '</tr></thead><tbody>';

    data.data.slice(0, 5).forEach(row => {
        tableHTML += '<tr>';
        data.columns.slice(0, 8).forEach(col => {
            tableHTML += `<td>${row[col]}</td>`;
        });
        tableHTML += '</tr>';
    });

    tableHTML += '</tbody></table>';
    document.getElementById('data-preview').innerHTML = tableHTML;
}

